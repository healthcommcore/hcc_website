<?php

defined('_JEXEC') or die();

require_once(JPATH_COMPONENT.DS.'controller.php');

$controller = new RokModuleController();


?>