<?php

defined('_JEXEC') or die();

jimport('joomla.application.component.controller');

class RokModuleController extends JController
{
	function __construct()
	{
		parent::__construct();

	}
}

?>