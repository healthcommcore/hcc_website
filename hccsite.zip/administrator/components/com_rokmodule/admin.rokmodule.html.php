<?php

defined('_JEXEC') or die();

class HTML_RokModule
{
	
}


?>